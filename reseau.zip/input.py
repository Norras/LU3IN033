



#read a file of trames and return a list of trames
def input():
    trames = [] # Liste des trames
    cur=[] # current trame
    with open('realforpy.txt', 'r') as f:
        lines=f.readlines()
        last=lines[-1]

        print(f.read())
        for line in lines:
            l=line.strip().split(' ')
            if l[0]=='0000':
                if cur!=[]:
                    trames.append(cur)
                    cur=[]
            if (len(l[3:])!=16 and (line!=last)):
                raise Exception("Trame invalide")
            cur.extend(l[3:])
            previousoffset=l[0]
    trames.append(cur)

    return trames


# Path: output.py
print("-------------------")
print("Output")
print(len(input()[0]))
print("-------------------")